import examAPI from "./exam";

let api = {
    exam: examAPI
};

export default api;

