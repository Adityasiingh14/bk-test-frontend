import platformAPI from "./platform";

let examAPI = {
    platform: platformAPI
};

export default examAPI;

