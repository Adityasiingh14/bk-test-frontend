import "./Subjective.css";

function Subjective() {
    return (
        <div className="subjective-subjective">
            <h1>
                Subjective
            </h1>
        </div>
    );
}

export default Subjective;

