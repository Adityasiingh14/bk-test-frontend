export { ExamPage } from './platform';
export { AnalysisPage } from './analysis';