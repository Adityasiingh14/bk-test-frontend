import "./Analysis.css";

function Analysis() {
  return (
    <div>
      <h1>Analysis</h1>
    </div>
  );
}

export default Analysis;

