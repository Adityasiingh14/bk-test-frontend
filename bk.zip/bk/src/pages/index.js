export { HomePage } from "./home";
export { ExamPage, AnalysisPage } from "./exam";
export { AuthPage } from "./auth";